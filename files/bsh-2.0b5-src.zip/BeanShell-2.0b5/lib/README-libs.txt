bsf.jar = bsf-2.3.0.jar
javacc.jar = javacc 3.x ?
servlet.jar = ?

