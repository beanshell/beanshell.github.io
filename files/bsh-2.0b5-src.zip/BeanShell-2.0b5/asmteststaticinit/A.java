public class A {
	static {
		System.out.println("foo!");
	}
}
